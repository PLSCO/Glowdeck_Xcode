#include "HardwareSerial.h"

HardwareSerial1 Serial1;

void serialEvent1() __attribute__((weak));
void serialEvent1() {}
